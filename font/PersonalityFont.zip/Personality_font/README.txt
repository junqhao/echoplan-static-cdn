PERSONALITY

An independent handwritten display font built from a brand-system experiment.

Personality started with a simple idea:
a loose handwritten visual cue could become a real, usable type system.

The original inspiration came from the expressive scribble language surrounding Instagram’s recent visual refresh — personal handwriting, imperfect forms, and a more human visual voice.

This is an independent release.
It is not affiliated with, endorsed by, or released by Instagram or Meta.


WHAT’S INCLUDED

Fonts
- Personality-Regular.otf
- Personality-Regular.ttf
- Personality-Regular.woff2

Individual glyph assets
- SVG glyphs
- Transparent PNG glyphs

Character set
- Uppercase A–Z
- Lowercase a–z
- Numbers 0–9
- Core punctuation and symbols


BEST FOR

Posters
Covers
Social graphics
Titles
Moodboards
Motion graphics
Brand experiments
Expressive typography


USAGE

For desktop design work, install the OTF or TTF file.

For web projects, use WOFF2.

The SVG and PNG folders contain individual glyph assets for custom compositions, motion, collage, and other workflows where using the font directly is less practical.


LICENSE

Personal and commercial use is allowed.

You may use and modify Personality inside your own design work, including client projects.

You may not redistribute, resell, repackage, or upload the font files or individual glyph assets as standalone downloadable assets.

See LICENSE.txt for full terms.


CREATED BY

Amir Mušić

More tools, experiments and design work:
https://amirmushich.com/

Original download page:
https://amirmushich.gumroad.com/

Make something imperfect.
